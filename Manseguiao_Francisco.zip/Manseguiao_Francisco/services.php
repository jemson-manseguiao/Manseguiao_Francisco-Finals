<!DOCTYPE html>
<html>
<head>
	<title>Services</title>
	<?php include_once 'dependencies.php'; ?>
</head>
<body>
<?php require 'db_connect.php';
 include_once 'header.php';
?>
<div>
<table class="table services-table">
	<td><div id="banner"><h1> <a href="check_services.php">Check Our Services</a></h1></div></td>
		<td><div id="banner" align="center"><h1><a href="book_test_Drive.php">Book A Test Drive</a></h1></div></td>
	<td><div id="banner" align="center"><h1><a href="promotions.php">Check Current Promotions</a></h1></div></td>

</table>
</div>
<?php include_once 'footer.php'; ?>
