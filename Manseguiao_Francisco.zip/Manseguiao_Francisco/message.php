<!DOCTYPE html>
<html>
<head>
<?php include_once 'dependencies.php';?>
	<title></title>
</head>
<body>
<div class="container">
<div class="alert alert-success" align="center">
  <strong>Your car was successfully added.</strong> You'll be notified whenever we finish fixing it.
</div>
</div>
</body>
</html>
<?php header('Refresh: 3; url=check_services.php'); ?>


