<!DOCTYPE html>
<html>
<head>
	<title>Contact Us</title>
	<?php include_once 'dependencies.php'; ?>
</head>
<body>
<?php require 'db_connect.php';


include_once 'header.php';
?>
 
<br> <br><br><br>
<div class="cointainer" align="center">


<a id="foxyform_embed_link_831223" href="http://www.foxyform.com/"></a>
<script type="text/javascript">
(function(d, t){
   var g = d.createElement(t),
       s = d.getElementsByTagName(t)[0];
   g.src = "http://www.foxyform.com/js.php?id=831223&sec_hash=1ab7d95f189&width=350px";
   s.parentNode.insertBefore(g, s);
}(document, "script"));
</script>
</div>

<?php include_once 'footer.php'; ?>
